import pytest
pytest.main(['.'])

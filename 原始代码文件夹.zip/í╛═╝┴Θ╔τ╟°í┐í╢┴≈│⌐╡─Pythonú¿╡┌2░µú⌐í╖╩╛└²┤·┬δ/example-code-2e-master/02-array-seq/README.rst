Sample code for Chapter 2 - "An array of sequences"

From the book "Fluent Python 2e" by Luciano Ramalho (O'Reilly)
http://shop.oreilly.com/product/0636920032519.do

# Mypy 0.812 can't spot this inevitable runtime IndexError
print([][0])
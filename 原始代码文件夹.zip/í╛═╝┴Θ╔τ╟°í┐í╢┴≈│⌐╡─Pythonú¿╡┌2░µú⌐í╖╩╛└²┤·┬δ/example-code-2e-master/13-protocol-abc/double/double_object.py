def double(x: object) -> object:
    return x * 2

#!/bin/bash
pytest --doctest-modules $2 $1 test_$1
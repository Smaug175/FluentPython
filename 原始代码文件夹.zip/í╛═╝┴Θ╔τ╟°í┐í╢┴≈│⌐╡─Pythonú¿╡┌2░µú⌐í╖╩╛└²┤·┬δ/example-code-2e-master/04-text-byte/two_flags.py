# REGIONAL INDICATOR SYMBOLS
RIS_A = '\U0001F1E6'  # LETTER A
RIS_U = '\U0001F1FA'  # LETTER U
print(RIS_A + RIS_U)  # AU: Australia
print(RIS_U + RIS_A)  # UA: Ukraine
print(RIS_A + RIS_A)  # AA: no such country

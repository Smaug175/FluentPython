class models:
    class Model:
        "nothing to see here"
    class IntegerField:
        "nothing to see here"

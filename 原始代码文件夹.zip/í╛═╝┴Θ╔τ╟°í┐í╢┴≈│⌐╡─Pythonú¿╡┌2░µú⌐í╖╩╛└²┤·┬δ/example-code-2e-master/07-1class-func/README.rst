Sample code for Chapter 7 - "First-class functions"

From the book "Fluent Python, Second Edition" by Luciano Ramalho (O'Reilly, 2020)
http://shop.oreilly.com/product/0636920273196.do
from birds import *

daffy = Duck()
alert(daffy)       # <1>
alert_duck(daffy)  # <2>
alert_bird(daffy)  # <3>

from collections import abc
from typing import Any

def double(n: abc.Sequence) -> Any:
    return n * 2


#!/bin/bash
scp FPY.LI.htaccess dh_i4p2ka@fpy.li:~/fpy.li/.htaccess

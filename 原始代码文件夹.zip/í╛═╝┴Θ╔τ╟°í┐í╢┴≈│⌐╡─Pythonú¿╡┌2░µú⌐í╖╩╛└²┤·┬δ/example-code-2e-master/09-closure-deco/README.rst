Sample code for Chapter 8 - "Closures and decorators"

From the book "Fluent Python, Second Edition" by Luciano Ramalho (O'Reilly, 2020)
http://shop.oreilly.com/product/0636920273196.do